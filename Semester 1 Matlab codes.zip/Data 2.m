% Calculate various matrix norms
norm_inf = norm(A, inf);  % Infinity norm
norm_1 = norm(A, 1);      % 1-norm
norm_2 = norm(A, 2);      % 2-norm (Spectral norm)
norm_F = norm(A, 'fro');  % Frobenius norm

% Display the results
disp('Infinity norm of A:');
disp(norm_inf);

disp('1-norm of A:');
disp(norm_1);

disp('2-norm (Spectral norm) of A:');
disp(norm_2);

disp('Frobenius norm of A:');
disp(norm_F);

