% Initialize matrix B
B= randi([1, 10], 4, 4);  % Random 4x4 matrix with integers from 1 to 10
disp('Initial matrix B:');
disp(B);

% (1) Double column 1
M1 = eye(4);
M1(1,1) = 2;
R1 = M1 * B;
disp('After doubling column 1:');
disp(R1);

% (2) Halve row 3
M2 = eye(4);
M2(3,3) = 0.5;
R2 = M2 * R1;
disp('After halving row 3:');
disp(R2);

% (3) Add row 3 to row 1
M3 = eye(4);
M3(1,3) = 1;
R3 = M3 * R2;
disp('After adding row 3 to row 1:');
disp(R3);

% (4) Interchange columns 1 and 4
M4 = eye(4);
M4([1,4],:) = M4([4,1],:);
R4 = R3 * M4;
disp('After interchanging columns 1 and 4:');
disp(R4);

% (5) Subtract row 2 from each of the other rows
M5 = eye(4);
M5([1,3,4],2) = -1;
R5 = M5 * R4;
disp('After subtracting row 2 from other rows:');
disp(R5);

% (6) Replace column 4 by column 3
M6 = eye(4);
M6(:,[3,4]) = [eye(4,1), zeros(4,1)];
R6 = R5 * M6;
disp('After replacing column 4 by column 3:');
disp(R6);

% (7) Delete column 1
M7 = [zeros(4,1), eye(4,3)];
R7 = R6 * M7;
disp('Final result after deleting column 1:');
disp(R7);

% (a) Result as a product of eight matrices
disp('(a) Result as a product of eight matrices:');
disp('R7 = M7 * M6 * M5 * M4 * M3 * M2 * M1 * B');

% (b) Result as a product ABC
A = M7 * M6 * M5 * M4;
C = M3 * M2 * M1;
disp('(b) Result as a product ABC:');
disp('R7 = A * B * C');
⁠
