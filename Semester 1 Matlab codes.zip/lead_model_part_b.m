% Parameters for part (b)
k = [0.0211, 0.0124, 0.000035, 0.0111, 0.0039, 0.0162]; % k01, k12, k13, k21, k31, k02
tspan = [0 1000]; % Time from 0 to 1000 days
x0 = [0; 0; 6]; % Initial conditions: x1(0) = 0, x2(0) = 0, x3(0) = 6

% ODE system
odefun = @(t, x) [-(k(1) + k(2) + k(3)) * x(1) + k(4) * x(2) + k(5) * x(3); ...
                   k(2) * x(1) - (k(6) + k(4)) * x(2); ...
                   k(3) * x(1) - k(5) * x(3)];

% Solve the ODE
[t, x] = ode45(odefun, tspan, x0);

% Plotting the results for part (b)
figure;
plot(t, x(:, 1), 'b', 'DisplayName', 'x1 (Blood)');
hold on;
plot(t, x(:, 2), 'g', 'DisplayName', 'x2 (Soft Tissues)');
plot(t, x(:, 3), 'r', 'DisplayName', 'x3 (Bones)');
xlabel('Time (days)');
ylabel('Amount of Lead (µg)');
legend;
title('Lead Distribution in 3-Compartment Model (Part b)');
grid on;
hold off;
