% Parameters for part (c) with k13 tripled
k_modified = [0.0211, 0.0124, 0.000105, 0.0111, 0.0039, 0.0162]; % k01, k12, k13 tripled, k21, k31, k02
tspan = [0 1000]; % Time from 0 to 1000 days
x0 = [0; 0; 6]; % Initial conditions: x1(0) = 0, x2(0) = 0, x3(0) = 6

% ODE system for modified k13
odefun_modified = @(t, x) [-(k_modified(1) + k_modified(2) + k_modified(3)) * x(1) + k_modified(4) * x(2) + k_modified(5) * x(3); ...
                            k_modified(2) * x(1) - (k_modified(6) + k_modified(4)) * x(2); ...
                            k_modified(3) * x(1) - k_modified(5) * x(3)];

% Solve the ODE with modified k13
[t_modified, x_modified] = ode45(odefun_modified, tspan, x0);

% Plotting the results for part (c)
figure;
plot(t_modified, x_modified(:, 1), 'b', 'DisplayName', 'x1 (Blood) with tripled k13');
hold on;
plot(t_modified, x_modified(:, 2), 'g', 'DisplayName', 'x2 (Soft Tissues) with tripled k13');
plot(t_modified, x_modified(:, 3), 'r', 'DisplayName', 'x3 (Bones) with tripled k13');
xlabel('Time (days)');
ylabel('Amount of Lead (µg)');
legend;
title('Lead Distribution with Tripled k13 (Part c)');
grid on;
hold off;
